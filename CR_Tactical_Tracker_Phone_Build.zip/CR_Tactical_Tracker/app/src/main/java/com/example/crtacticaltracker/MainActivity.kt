package com.example.crtacticaltracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Black = Color(0xFF050705)
private val Panel = Color(0xFF0B100B)
private val Orange = Color(0xFFFF8A00)
private val Green = Color(0xFF39FF14)
private val SoftGreen = Color(0xFFB6FF9C)

private val DragonScheme = darkColorScheme(
    primary = Orange,
    secondary = Green,
    background = Black,
    surface = Panel,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = DragonScheme) {
                Surface(Modifier.fillMaxSize(), color = Black) {
                    TrackerScreen()
                }
            }
        }
    }
}

@Composable
private fun DragonPanel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(2.dp, Orange),
        colors = CardDefaults.cardColors(containerColor = Panel),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Column(
            Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
            content = content
        )
    }
}

@Composable
fun TrackerScreen() {
    var opponentElixir by remember { mutableIntStateOf(5) }
    var opponentCards by remember { mutableStateOf(List(8) { "" }) }
    var played by remember { mutableStateOf(listOf<String>()) }
    var cardInput by remember { mutableStateOf("") }

    val usedCounts = played.groupingBy { it }.eachCount()
    val knownCards = opponentCards.filter { it.isNotBlank() }.distinct()
    val nextCycleCandidates = knownCards.filter { (usedCounts[it] ?: 0) == 0 }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Black).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item {
            DragonPanel {
                Text("🐉  CR TACTICAL TRACKER", style = MaterialTheme.typography.headlineSmall, color = Green)
                Text("ЧЁРНЫЙ ДРАКОН • ТАКТИЧЕСКАЯ ПАНЕЛЬ", color = Orange, style = MaterialTheme.typography.labelMedium)
                Text("Помощник для ручного анализа матча", color = SoftGreen)
            }
        }
        item {
            DragonPanel {
                Text("🧪 ЭЛИКСИР ПРОТИВНИКА", color = Green, style = MaterialTheme.typography.titleMedium)
                Text("$opponentElixir / 10", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                Slider(
                    value = opponentElixir.toFloat(),
                    onValueChange = { opponentElixir = it.toInt().coerceIn(0, 10) },
                    valueRange = 0f..10f,
                    steps = 9,
                    colors = SliderDefaults.colors(
                        thumbColor = Orange,
                        activeTrackColor = Green,
                        inactiveTrackColor = Color.DarkGray
                    )
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { opponentElixir = (opponentElixir - 1).coerceAtLeast(0) },
                        border = BorderStroke(1.dp, Orange)
                    ) { Text("−1", color = Orange) }
                    OutlinedButton(
                        onClick = { opponentElixir = (opponentElixir + 1).coerceAtMost(10) },
                        border = BorderStroke(1.dp, Orange)
                    ) { Text("+1", color = Orange) }
                }
                Text("Оценка вводится вручную — скрытые данные игры не считываются.", color = SoftGreen, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Text("👁️ КОЛОДА ПРОТИВНИКА", color = Green, style = MaterialTheme.typography.titleMedium)
        }
        itemsIndexed(opponentCards) { index, card ->
            OutlinedTextField(
                value = card,
                onValueChange = { value ->
                    opponentCards = opponentCards.toMutableList().also { it[index] = value.take(30) }
                },
                label = { Text("Карта ${index + 1}") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Orange,
                    unfocusedBorderColor = Color(0xFF8B5A20),
                    focusedLabelColor = Green,
                    cursorColor = Green
                )
            )
        }
        item {
            DragonPanel {
                Text("🔄 ЦИКЛ КАРТ", color = Green, style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = cardInput,
                    onValueChange = { cardInput = it },
                    label = { Text("Какая карта только что сыграна?") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Orange,
                        unfocusedBorderColor = Color(0xFF8B5A20),
                        focusedLabelColor = Green,
                        cursorColor = Green
                    )
                )
                Button(
                    onClick = {
                        if (cardInput.isNotBlank()) {
                            played = (played + cardInput.trim()).takeLast(32)
                            cardInput = ""
                        }
                    },
                    enabled = cardInput.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
                ) { Text("ЗАПИСАТЬ КАРТУ") }
                Text(
                    "Последние действия: ${played.takeLast(8).asReversed().joinToString(" • ").ifBlank { "пока нет" }}",
                    color = SoftGreen
                )
                Text("Возможные карты по твоим записям:", color = Green)
                Text(nextCycleCandidates.joinToString(", ").ifBlank { "Недостаточно введённых данных" })
                Text("Это подсказка по введённым данным, не точное раскрытие следующей карты.", color = SoftGreen, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(
                    onClick = { played = emptyList(); opponentElixir = 5 },
                    border = BorderStroke(1.dp, Orange)
                ) { Text("СБРОСИТЬ МАТЧ", color = Orange) }
            }
        }
        item {
            Text(
                "Приложение не подключается к Clash Royale и не читает память игры или серверные данные Supercell.",
                color = Color.LightGray,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
